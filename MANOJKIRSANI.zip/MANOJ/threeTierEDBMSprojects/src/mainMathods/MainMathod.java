  package mainMathods;
import java.util.List;
import java.util.Scanner;
import entity.Entity;
import methods.Mathods;
public class MainMathod {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Entity E=new Entity();
		Mathods M=new Mathods(); 
		while(true)
		{
			System.out.println("1 FOR CREATE THE TABLE !");
			System.out.println("2 FOR DATA INSERT THE TABLE !");
			System.out.println("3 FOR UPDATE TABLE !");
			System.out.println("4 FOR DELETE EMPLYEE RECORD");
			System.out.println("5 FOR SEARCH RECORD BY ID !");
			System.out.println("6 FOR SEARCH ID OR NAME !");
			System.out.println("7 FOR DISPLAY LAST 4 EMPLOYEE RECORD !");
			System.out.println("8 FOR SHOW THE DETAILS !");
			System.out.println("10 FOR EXIT !");
			System.out.println("CHOOSE THE OPTION !");
			int op=sc.nextInt();
			switch(op)
			{
			case 1:
			{
				M.createTable();
			}
			break;
			case 2:
			{
				System.out.println("ENTER THE EMPLOYEE ID !");
				int id=sc.nextInt();
				System.out.println("ENTER THE EMPLOYEE NAME !");
				sc.nextLine();
				String name=sc.nextLine();
				System.out.println("ENTER THE EMPLOYEE SALARY !");
				double salary = sc.nextDouble();
				System.out.println("ENTER THE EMPLOYEE DEPARTMENT !");
				sc.nextLine();
				String dept = sc.nextLine();
				System.out.println("ENTER THE EMPLOYEE LOCATION !");
				String location = sc.nextLine();
				E.setEid(id);
				E.setEname(name);
				E.setSalary(salary);
				E.setDepat(dept);
				E.setLocation(location);
				M.insertTable(E);			
			}
			break;
			case 3:
			{
			System.out.println("ENTER THE ID !");
			int eid= sc.nextInt();
			sc.nextLine();
			System.out.println("ENTER THE NEW ADDRESS !");
			String nname=sc.nextLine();
			M.updateTable(nname,eid);
			}
			break;
			case 4:
			{
				System.out.println("ENTER THE EMPLOYEE ID !");
				int did=sc.nextInt();
				M.deleteEmployee(did);
			}
			break;
			case 5:
			{
				System.out.println("ENTER THE EMPLOYEE ID !");
				int rid=sc.nextInt();
				M.searchByid(rid);
			}
			break;
			case 6:
			{
				System.out.println("ENTER THE NAME OR ID");
				int oid=sc.nextInt();
				String ni=sc.nextLine();
				M.searchBYidorName(ni,oid);
			}
			case 7:
			{
//				System.out.println("ENTER THE ID !");
//				int x = sc.nextInt();
				List<Entity> s=M.showLast4Details();
				for(Entity w:s)
				{
				System.out.println("EID :"+w.getEid());
				System.out.println("ENAME :"+w.getEname());
				System.out.println("ESALARY :"+w.getSalary());
				System.out.println("EDEPAT :"+w.getDepat());
				System.out.println("ELOCATION :"+w.getLocation());
				}
			}
			case 8:
			{
				List<Entity> s=M.showDetails();
				for(Entity w:s)
				{
				System.out.println("EID :"+w.getEid());
				System.out.println("ENAME :"+w.getEname());
				System.out.println("ESALARY :"+w.getSalary());
				System.out.println("EDEPAT :"+w.getDepat());
				System.out.println("ELOCATION :"+w.getLocation());
				}
			}
			break;
			case 10:
				System.exit(0);
				break;
			default:
				System.out.println("invalid !");
			}
		}
	}

}
