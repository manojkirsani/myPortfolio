package methods;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import entity.Entity;
public class Mathods {
	static Connection con;
	PreparedStatement ps;
	ResultSet rs;
	public  static Connection  getCon()
	{
	   
		try
	    {
			Class.forName("com.mysql.cj.jdbc.Driver");
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ems2","root","Manoj@123");
	    	
	    }
		catch(Exception E)
		{
			System.out.println("Exception is"+E);
		}
		return con;
	}
	public void createTable()
	{
		Mathods.getCon();
		try
		{
		ps=con.prepareStatement("create table employ("
				+ "eid int primary key,"
				+ "ename varchar(80) unique,"
				+ "esalary double(20,3),"
				+ "edepat varchar(80),"
				+ "elocation varchar(80))");
		int r = ps.executeUpdate();
		if(r==1)
		{
			System.out.println("TABLE CREATE SUCCESS FULL !");
		}
		}
		catch(Exception E)
		{
			System.out.println("erorr"+E);
		}
	}
    public void insertTable(Entity E)
    {
    	Mathods.getCon();
    	try
    	{
    		ps=con.prepareStatement("insert into employ values(?,?,?,?,?)");
    		ps.setInt(1,E.getEid());
    		ps.setString(2,E.getEname());
    		ps.setDouble(3,E.getSalary());
    		ps.setString(4,E.getDepat());
    		ps.setString(5,E.getLocation());
    		int r= ps.executeUpdate();
    		if(r==1)
    		{
    			System.out.println("INSERT SUCCESSFUL !  ");
    		}
    	}
    	catch(Exception e)
    	{
    	System.out.println(e);	
    	}
    }
    public void updateTable(String eloca,int eid)
    {
    	Mathods.getCon();
    	try
    	{
    	ps=con.prepareStatement("update employ set elocation= ? where eid = ?");
    	ps.setString(1,eloca);
    	ps.setInt(2,eid);
    	int r = ps.executeUpdate();
    	if(r==1)
    	{
    	System.out.println("UPDATE SUCCESS FUL !");	
    	}
    	}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    }
    public void deleteEmployee(int id)
    {
    	Mathods.getCon();
    	try
    	{
    		ps=con.prepareStatement("delete from employ where eid=?");
    		ps.setInt(1, id);
    		int r= ps.executeUpdate();
    		if(r==1) {
    			System.out.println("DELETE SUCCES FULL !");}
    		}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    }
    public void searchByid(int id)
    {
    	Mathods.getCon();
    	try
    	{
    		ps=con.prepareStatement("select * from employ where eid = ? ");
    		ps.setInt(1, id);
    		rs = ps.executeQuery();
    		while(rs.next())
    		{
    			System.out.println("NAME :"+rs.getString(2));
    			System.out.println("SALARY :"+rs.getDouble(3));
    			System.out.println("DEPARTMENT :"+rs.getString(4));
    			System.out.println("LOCATION :"+rs.getString(5));
    		}
    	}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    }
    public void searchBYidorName(String s,int eid)
    {
    	Mathods.getCon();
    	try
    	{
    	ps=con.prepareStatement("select * from employ where eid= ? or ename=?");
    	//ps.setString(2,s);
    	ps.setInt(1, eid);
    	rs=ps.executeQuery();
    	while(rs.next())
    	{
    		System.out.println("NAME :"+rs.getString(2));
			System.out.println("SALARY :"+rs.getDouble(3));
			System.out.println("DEPARTMENT :"+rs.getString(4));
			System.out.println("LOCATION :"+rs.getString(5));
    	}
    	}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    }
    public List<Entity> showDetails()
    {
    	Mathods.getCon();
    	Entity e=null;
    	List<Entity> el=new ArrayList<Entity>();
    	try
    	{
    		ps=con.prepareStatement("select  * from employ ");
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    		e=new Entity();
    		e.setEid(rs.getInt(1));
    		e.setEname(rs.getString(2));
    		e.setSalary(rs.getDouble(3));
    		e.setDepat(rs.getString(4));
    		e.setLocation(rs.getString(5));
    		el.add(e);
    		}
    	}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    	return el;
    }
    public List<Entity> showLast4Details()
    {
    	Mathods.getCon();
    	Entity e=null;
    	List<Entity> el=new ArrayList<Entity>();
    	try
    	{
    		ps=con.prepareStatement("select  * from employ where eid order by eid desc limit 5");
    		//ps.setInt(1, x);
    		rs=ps.executeQuery();
    		while(rs.next())
    		{
    		e=new Entity();
    		e.setEid(rs.getInt(1));
    		e.setEname(rs.getString(2));
    		e.setSalary(rs.getDouble(3));
    		e.setDepat(rs.getString(4));
    		e.setLocation(rs.getString(5));
    		el.add(e);
    		}
    	}
    	catch(Exception E)
    	{
    		System.out.println(E);
    	}
    	return el;
    }
}
