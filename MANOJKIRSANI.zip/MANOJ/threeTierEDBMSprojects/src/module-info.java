/**
 * 
 */
/**
 * @author ASUS
 *
 */
module threeTierEDBMSprojects {
	requires java.sql;
}