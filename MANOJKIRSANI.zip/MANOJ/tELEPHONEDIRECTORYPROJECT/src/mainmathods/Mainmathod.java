package mainmathods;
import java.util.*;
import entity.Entity;
import mathods.Mathods;

public class Mainmathod {
public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	Entity e=new Entity();
	Entity f=new Entity();
	Mathods m=new Mathods();
	while(true)
	{
		System.out.println("1 FOR CREATE TABLE !");
		System.out.println("2 FOR INSERT CONSUMER TABLE INSERT !");
		System.out.println("3 FOR INSERT CUSTOMER TABLE INSERT !");
		System.out.println("4 INCLUDE BOTH TABLE AND SEARCH BY ID !");
		System.out.println("5 FOR SHOW DETAILS INCLUDE ALL !");
		System.out.println("6 FOR UPDATE CUSTOMER NAME BY ID !");
		System.out.println("7 FOR DELETE CUSTOMER RECORD BY ID !");
		System.out.println("8 FOR LAST 10 CUSTOMER !");
		System.out.println("9 FOR EXIT");
		System.out.println("10 FOR SHOW LAST 2 RECORDS");
		System.out.println("CHOOSE THE OPTION !");
		int a= sc.nextInt();
		System.out.println("=====================================================");
		switch(a)
		{
		case 1:
			boolean x=m.createTablecustomer();		{
			if(x==true)
			{
				System.out.println("CREATE TABLE SUCCESS FULL !");
			}
		}
			break;
		case 2:
		{
			
			System.out.println("ENTER THE OFFICE ID IN STRING !");
			int id=sc.nextInt();
			e.setOfficeid(id);
			sc.nextLine();
			System.out.println("ENTER THE OFFICE ADDRESS !");
			String adres=sc.nextLine();
			e.setOfficeadress(adres);
			System.out.println("ENTER THE OFFICE MOBILE NO!");
			int mob=sc.nextInt();
			e.setOfficemob(mob);
			boolean y=m.insertCunsumerTable(e);
			if(y==true)
			{
				System.out.println("INSERT CONSUMER TABLE SUCCESS FULL !");
			}
		}
		break;
		case 3:
		{
			sc.nextLine();
			System.out.println("ENTER THE CUSTOMER ID !");
			int cid=sc.nextInt();
			f.setCid(cid);
			sc.nextLine();
			System.out.println("ENTER THE CUSTOMER NAME !");
			String cname=sc.nextLine();
			f.setCname(cname);
			System.out.println("ENTER THE CUSTOMER MOB NUMBER !");
			int cmob=sc.nextInt();
			f.setMob(cmob);
			System.out.println("ENTER THE OFFICE ID(FOREIGN KEY)");
			int mb = sc.nextInt();
			f.setOfficeid(mb);
			boolean z=m.insertCustomerTable(f);
			if(z==true)
			{
				System.out.println("INSERT CUSTOMER TABLE SUCCESS FULL !");
			}
		}
		break;
		case 4:
		{
			System.out.println("ENTER THE ID");
			int sid=sc.nextInt();
			Entity ex =m.searchByid(sid);
			System.out.println("cname :"+ex.getCname()+"office adress :"+ex.getOfficeadress()+"office mob :"+ex.getOfficemob());
		}
		break;
		case 5:
		{
			List<Entity> ne=m.showDetails();
			for(Entity fn:ne)
			{
				System.out.println("cid :"+fn.getCid()+"\t"+"cname :"+fn.getCname()+"\t"+"mob :"+fn.getMob()+"\t"+"cadd :"+fn.getOfficeadress()+"\t"+"office mob:"+fn.getOfficemob());
			}
		}
		break; 
		case 6:
		{
			System.out.println("ENTER THE ID :");
			int d=sc.nextInt();
			sc.nextLine();
			System.out.println("ENTER THE NEW NAME :");
			String nn=sc.nextLine();
			boolean d1=m.updateByid(nn,d);
			if(d1==true)
			{
			System.out.println("EDIT SUCCESSFULL ");	
			}
		}
		break;
		case 7:
		{
			System.out.println("ENTER THE DELETE ID !");
			int d2=sc.nextInt();
			boolean d3=m.deleteByid(d2);
			if(d3==true)
			{
				System.out.println("DELETE SUCCESS FULL !");
			}
		}
		break;
		case 8:
		{
			List<Entity> nem=m.showDetails();
			for(Entity fn1:nem)
			{
				System.out.println("cid :"+fn1.getCid()+"\t"+"cname :"+fn1.getCname()+"\t"+"mob :"+fn1.getMob()+"\t"+"cadd :"+fn1.getOfficeadress()+"\t"+"office mob:"+fn1.getOfficemob());
			}
		}
		break;
		case 10:
		{
			m.showLAST2();
		}
		break;
		case 9:
		{
			System.exit(0);
		}
		break;
		default:
			System.out.println("INVALID  !");
		}
	}
}
}
