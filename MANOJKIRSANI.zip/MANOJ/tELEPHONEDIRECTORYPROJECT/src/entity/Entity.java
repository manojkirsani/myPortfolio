package entity;

public class Entity {
         private int cid;
         public int getCid() {
			return cid;
		}
		public void setCid(int cid) {
			this.cid = cid;
		}
		public String getCname() {
			return cname;
		}
		public void setCname(String cname) {
			this.cname = cname;
		}
		public int getMob() {
			return mob;
		}
		public void setMob(int mob) {
			this.mob = mob;
		}
		public int getOfficeid() {
			return officeid;
		}
		public void setOfficeid(int officeid) {
			this.officeid = officeid;
		}
		public String getOfficeadress() {
			return officeadress;
		}
		public void setOfficeadress(String officeadress) {
			this.officeadress = officeadress;
		}
		public int getOfficemob() {
			return officemob;
		}
		public void setOfficemob(int officemob) {
			this.officemob = officemob;
		}
		private String cname;
         private int mob;
         private int officeid;
         private String officeadress;
         private int officemob;
}
