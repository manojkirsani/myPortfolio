/**
 * 
 */
/**
 * @author ASUS
 *
 */
module tELEPHONEDIRECTORYPROJECT {
	requires java.sql;
}