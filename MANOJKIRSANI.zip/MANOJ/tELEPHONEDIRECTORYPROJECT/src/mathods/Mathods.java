 package mathods;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import customerMethod.CustomerMethod;
import entity.Entity;
public class Mathods {
	static Connection con;
	PreparedStatement ps;
	ResultSet rs;
	public  static Connection  getCon()
	{
	   
		try
	    {
			Class.forName("com.mysql.cj.jdbc.Driver");
	    	con=DriverManager.getConnection("jdbc:mysql://localhost:3306/telephoneprojectfinal","root","Manoj@123");
	    	
	    }
		catch(Exception E)
		{
			System.out.println("Exception is"+E);
		}
		return con;
	}
	public boolean createTablecustomer()
	{   boolean status=false;
		Mathods.getCon();
		try
		{
		ps=con.prepareStatement("create table customer2("
				+ "cid int primary key ,"
				+ "cname varchar(80),"
  			+ "mob int,fid int,foreign key(fid) references consumer(ofid))");
    	ps=con.prepareStatement("create table consumer("
  			+ "ofid int primary key,ofadres varchar(80),ofmob int)");
	    ps.executeUpdate();
		}
		catch(Exception E)
		{
			System.out.println("erorr"+E);
		}
		return true;
	}
	public boolean insertCunsumerTable(Entity e)
	{     boolean status=false;
		Mathods.getCon();
		try
		{
			ps=con.prepareStatement("insert into consumer values (?,?,?)");
			ps.setInt(1,e.getOfficeid());
			ps.setString(2,e.getOfficeadress());
			ps.setInt(3,e.getOfficemob());
			ps.executeUpdate();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return true;
	}
	public boolean insertCustomerTable(Entity f)
	{
		boolean status = false;
		Mathods.getCon();
		try
		{
			ps=con.prepareStatement("insert into customer2 values (?,?,?,?)");
			ps.setInt(1,f.getCid());
			ps.setString(2,f.getCname());
			ps.setInt(3,f.getMob());
			ps.setInt(4,f.getOfficeid());
			ps.executeUpdate();
			
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return true;
	}
	public Entity searchByid(int x)
	{   Mathods.getCon();
	    Entity e=new Entity(); 
		try
		{
			ps=con.prepareStatement("select cname,ofadres,ofmob from customer2 join consumer on  customer2.fid=consumer.ofid where cid=?");
			ps.setInt(1,x);
			rs=ps.executeQuery();
			while(rs.next())
			{
			e.setCname(rs.getString(1));
			e.setOfficeadress(rs.getString(2));
			e.setOfficemob(rs.getInt(3));
			}
		}
		catch(Exception E)
		{
		System.out.println(E);	
		}
		return e;
	}
	public List<Entity> showDetails()
	{
		Mathods.getCon();
		Entity n=null;
		List<Entity> en=new ArrayList<Entity>();
		try
		{
		ps=con.prepareStatement("select cid,cname,mob,ofadres,ofmob from customer2 join consumer on customer2.fid=consumer.ofid");
		rs=ps.executeQuery();
		while(rs.next())
		{
			n=new Entity();
			n.setCid(rs.getInt(1));
			n.setCname(rs.getString(2));
			n.setMob(rs.getInt(3));
			n.setOfficeadress(rs.getString(4));
			n.setOfficemob(rs.getInt(5));
			en.add(n);
		}
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return en;
	}
	public boolean updateByid(String s,int r)
	{
		boolean status=false;
		Mathods.getCon();
		try
		{
		ps=con.prepareStatement("update customer2 set cname=? where cid=?");
		ps.setString(1,s);
		ps.setInt(2,r);
		ps.executeUpdate();
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return true;
	} 
	public boolean deleteByid(int r)
	{
		boolean status=false;
		Mathods.getCon();
		try
		{
		ps=con.prepareStatement("delete from customer2 where cid = ? ");
		ps.setInt(1,r);
		ps.executeUpdate();
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return true;
	}
	public List<Entity> showDetailsLast10Customer()
	{
		Mathods.getCon();
		Entity n1=null;
		List<Entity> en1=new ArrayList<Entity>();
		try
		{
		ps=con.prepareStatement("select cid,cname,mob,ofadres,ofmob from customer2 join consumer on customer2.fid=consumer.ofid where cid order by cid desc limit 2 ");
		rs=ps.executeQuery();
		while(rs.next())
		{
			n1=new Entity();
			n1.setCid(rs.getInt(1));
			n1.setCname(rs.getString(2));
			n1.setMob(rs.getInt(3));
			n1.setOfficeadress(rs.getString(4));
			n1.setOfficemob(rs.getInt(5));
			en1.add(n1);
		}
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
		return en1;
	}
	public void showLAST2()
	{
		Mathods.getCon();
		try
		{
			ps=con.prepareStatement("select cid,cname,mob,ofadres,ofmob from customer2 join consumer on customer2.fid=consumer.ofid where cid order by cid desc limit 2 ");
			rs=ps.executeQuery();
			while(rs.next())
			{
				System.out.println(rs.getInt(1));
				System.out.println(rs.getString(2));
				System.out.println(rs.getInt(3));
				System.out.println(rs.getString(4));
				System.out.println(rs.getInt(5));
				
			}
		}
		catch(Exception E)
		{
			System.out.println(E);
		}
	}
	
}
