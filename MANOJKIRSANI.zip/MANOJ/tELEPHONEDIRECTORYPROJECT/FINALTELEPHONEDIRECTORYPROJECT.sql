create database telephoneprojectfinal;
use telephoneprojectfinal;
select * from consumer;
select * from customer2;
desc table consumer;